#include<stdio.h>
int lmn()
{
printf("left\n");
return 0;
}
int pqr()
{
printf("right\n");
return 1;
}
int main()
{
int x;
x=lmn() || pqr();
printf("%d",x);
return 0;
}