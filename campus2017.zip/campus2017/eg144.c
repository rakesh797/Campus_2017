#include<stdio.h>
#include<string.h>
int main()
{
char a[81],b[81];
strcpy(a,"Mumbai");
strcpy(b,"mumbai");
char *p=strdup(b);
printf("%s\n",p);
return 0;
}