#include<stdio.h>
#define TRUE 1
#define FALSE 0
#define isdigit(x) (x>=48 && x<=57)?TRUE:FALSE
#define isnondigit(x) !isdigit(x)
int main()
{
char m;
m='A';
if(isdigit(m)){
printf("%c is a digit\n",m);
}else
{
printf("%c is not a digit\n",m);
}
if(isnondigit(m)){
printf("%c is not a digit\n",m);
}else
{
printf("%c is a digit\n",m);
}
}