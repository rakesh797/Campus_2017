#include<stdio.h>
int main()
{
char x;
x=129;
printf("%d",x);
return 0;
}