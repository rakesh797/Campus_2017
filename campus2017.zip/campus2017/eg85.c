#include<stdio.h>
int main()
{
char m[6];
printf("%d %d\n",sizeof(m),sizeof(m[0]));
printf("%d\n",m);
printf("%u\n",m);
m[0]='A';
m[1]='B';
m[3]='C';
m[4]='D';
m[5]='E';
printf("%d %d\n",sizeof(&m[0]),sizeof(m[0]));
printf("%d\n",&m[0]);
printf("%u\n",&m[0]);
return 0;
}