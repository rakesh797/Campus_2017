#include<stdio.h>
int main()
{
int printf;
printf("God id great");
return 0;
}