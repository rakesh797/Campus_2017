#include<stdio.h>
void thinkingmachines(char *,char *);
int main()
{
char a[81],b[81];
printf("Enter a string");
gets(a);
thinkingmachines(b,a);
printf("%s",a);
printf("%s",b);
return 0;
}
void thinkingmachines(char *p,char *q)
{
while(*q!='\0')
{
*p=*q;
q++;
p++;
}
*p='\0';
}