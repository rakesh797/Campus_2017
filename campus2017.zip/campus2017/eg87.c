#include<stdio.h>
#include<stdarg.h>
int add(int num,...)
{
va_list valist;
int sum=0;
int i=0;
va_start(valist,num);
for(int i=0;i<num;i++)
{
sum+=va_arg(valist,int);
}
va_end(valist);
return sum;
}
int main()
{
printf("%d\n",add(3,10,20,30));
printf("%d\n",add(2,50,30));
printf("%d\n",add(7,10,20,30,40,50,60,70));
return 0;
}