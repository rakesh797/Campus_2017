#include<stdio.h>
int main()
{
char x;
x=-131;
printf("%d",x);
return 0;
}