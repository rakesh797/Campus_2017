#include<stdio.h>
#define x printf
int main()
{
int x;
x("god is great\n");
return 0;
}