#include<stdio.h>
int thinkingmachines(char *);
int main()
{
char a[21];
printf("Enter a string :");
gets(a);
printf("%d\n",thinkingmachines(a));
return 0;

}
int thinkingmachines(char *p)
{
char *q;
for(q=p;*q!='\0';q++);
return q-p;
}