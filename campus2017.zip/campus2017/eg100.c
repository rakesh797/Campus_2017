#include<stdio.h>
int thinkingmachines(char *);
int main()
{
char a[81];
printf("Enter a string");
gets(a);
printf("%d\n",thinkingmachines(a));
return 0;
}
int thinkingmachines(char *p)
{
int k=0;
while(*p!='\0')
{
p++;
k++;
}
return k;
}