#include<stdio.h>
#define max(x,y) (x>y)?x:y
int main()
{
int j,t;
j=100;
t=200;
printf("%d",max(j,t));
return 0;
}