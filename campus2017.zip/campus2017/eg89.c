#include<stdio.h>
int main()
{
int m[6];
printf("%d %d\n",sizeof(m),sizeof(m[0]));
printf("%d\n",m);
printf("%u\n",m);
printf("%u\n",&m);
m[0]=65;
m[1]=66;
m[2]=67;
m[3]=68;
m[4]=69;
m[5]=70;
printf("%d %d\n",sizeof(&m[0]),sizeof(m[0]));
printf("%d\n",&m[0]);
printf("%u\n",&m[0]);
return 0;
}