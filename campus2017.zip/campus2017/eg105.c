#include<stdio.h>
void thinkingmachines(char *);
int main()
{
char a[81];
printf("Enter a string");
gets(a);
thinkingmachines(a);
printf("[%s]\n",a);
return 0;
}
void thinkingmachines(char *p)
{
char *q,*j,*m;
q=p;
while(*q!='\0')
{
for(j=m=q;*m==' ';m++);
if(j!=m)
{
if(j!=p)
j++;
while(*m!='\0')
{
*j=*m;
j++;
m++;
}
*j='\0';
}
q++;
}
if(*(q-1)==' ')
*(q-1)='\0';
}