#include<stdio.h>
int x;
void cool()
{
printf("Cool");
}