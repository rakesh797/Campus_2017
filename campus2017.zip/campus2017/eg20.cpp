#include<stdio.h>
int main()
{
int x;
x=printf("Hello\n");
printf("%d",x);
return 0;
}