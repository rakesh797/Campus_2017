#include<stdio.h>
void lmn();
int main()
{
lmn();
lmn();
lmn();
}
void lmn()
{
int x=1;
printf("%d\n",x);
x++;
}