#include<stdio.h>
int main()
{
int x=1;
if(--x || x++ || ++x || --x || ++x)
{
printf("Great\n");
}
printf("%d",x);
return 0;
}