#include<stdio.h>
void thinkingmachines(char *,char *);
int main()
{
char a[81],b[81];
printf("Enter a string");
gets(a);
printf("Enter another string");
gets(b);
thinkingmachines(a,b);
printf("%s",a);
return 0;
}
void thinkingmachines(char *p,char *q)
{
for(;*p!='\0';p++);
for(;*q!='\0';*p=*q,q++,p++);
*p='\0';
}