#include<stdio.h>
int lmn();
int pqr();
int main()
{
printf("%d %d\n",lmn(),pqr());
return 0;
}
int lmn()
{
printf("One\n");
return 1;
}
int pqr()
{
printf("two\n");
return 2;
}
