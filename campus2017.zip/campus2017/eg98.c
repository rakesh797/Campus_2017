#include<stdio.h>
int main()
{
int x[5];
*(&x[0])=10;
printf("%d\n",x[0]);
return 0;
}