#include<stdio.h>
#define i 10
void main(int j)
{
while(j<10)
{
if(printf("%d",j++))
{

}
}
}