#include<stdio.h>
int main()
{
char x;
x=127;
x=x<<2;
printf("%d",x);
return 0;
}