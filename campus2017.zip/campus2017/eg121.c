#include<stdio.h>
int main()
{
int x[10],y,lookFor,count;
y=0;
while(y<=9)
{
printf("Enter a number");
scanf("%d",&x[y]);
y++;
}
printf("Enter the number to look for ");
scanf("%d",&lookFor);
y=0;
count=0;
while(y<=9)
{
if(lookFor==x[y])
{
count++;
}
y++;
}
if(count==1)
{
printf("%d occurs %d times",lookFor,count);
}
return 0;
}