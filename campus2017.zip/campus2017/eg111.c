#include<stdio.h>
void thinkingmachines(char *);
int main()
{
char a[81];
printf("Enter a string");
gets(a);
thinkingmachines(a);
printf("%s",a);
return 0;
}
void thinkingmachines(char *p)
{
int x;
for(x=0;*(p+x+1);x++);
while(p<p+x)
{
*p=*p+*(p+x);
printf("%u %u\n",p,p+x);
*(p+x)=*p-*(p+x);
*p=*p-*(p+x);
x-=2;// this is because p++ to reach the required address we need to subtract with 2;
p++;
}
}