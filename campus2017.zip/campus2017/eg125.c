#include<stdio.h>
typedef char name[21];
typedef char address[101];
int main()
{
name s;
address g;
return 0;
}