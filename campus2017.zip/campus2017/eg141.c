#include<stdio.h>
#define isdigit(x) (x>=48 && x<=57)?1:0
#define isnondigit(x) !isdigit(x)
int main()
{
char m;
m='A';
if(isdigit(m))
{
printf("%c is a digit\n",m);
}else
{
printf("%c is a not a digit\n",m);
}
if(isnondigit(m)){
printf("%c is not a digit\n",m);
}else
{
printf("%d is a digit\n",m);
}
}