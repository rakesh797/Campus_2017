#include<stdio.h>
int main()
{
int x;
x=-2147483649;
printf("%d\n",x);
return 0;
}