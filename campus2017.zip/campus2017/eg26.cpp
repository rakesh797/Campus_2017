#include<stdio.h>
int lmn();
int pqr();
int main()
{
int x;
x=lmn() || pqr();
printf("%d",x);
return 0;
}
int lmn()
{
printf("left\n");
return 1;
}
int pqr()
{
printf("right\n");
return 1;
}