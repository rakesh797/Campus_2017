#include<stdio.h>
int main()
{
int m[6];
m[0]=65;
m[1]=66;
m[2]=67;
m[3]=68;
m[4]=69;
m[5]=70;
printf("%u\n",m);
printf("%u\n",&m[0]);
printf("%u\n",&m[4]);
printf("%u\n",m+4);
printf("%u\n",&m-4);
return 0;
}