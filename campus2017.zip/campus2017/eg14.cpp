#include<stdio.h>
int main()
{
int x;
x=10<20 && 30<100;
printf("%d",x);
return 0;
}