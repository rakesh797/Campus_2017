#include<stdio.h>
int main()
{
char x;
x=130;
printf("%d",x);
return 0;
}