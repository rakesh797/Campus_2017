#include<stdio.h>
int thinkingmachines(char *,char *);
int main()
{
char a[81],b[11];
int x;
printf("Enter a string");
gets(a);
printf("Enter another string");
gets(b);
x=thinkingmachines(a,b);
printf("%d",x);
return 0;
}
int thinkingmachines(char *p,char *q)
{
int x=0;
char *j1,*j2;
while(*p)
{
for(j1=p,j2=q;*j1==*j2 && *j1 && *j2;j1++,j2++);
if(!*j2)
x++;
p++;
}
return x;
}