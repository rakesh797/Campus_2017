#include<stdio.h>
void thinkingmachines(char *);
int main()
{
char a[81];
printf("Enter a string");
gets(a);
thinkingmachines(a);
printf("%s",a);
return 0;
}
void thinkingmachines(char *p)
{
char *q=p;
while(*q)
{
*q=((p==q || (q>p && *(q-1)==' ')) && *q>=97 && *q<=122)?*q-=' ':*q;
q++;
}
}