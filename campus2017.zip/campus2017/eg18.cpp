#include<stdio.h>
int main()
{
int x;
x=(1 || 1) && 0;
printf("%d",x);
return 0;
}