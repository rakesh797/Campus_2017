#include<stdio.h>
int main()
{
int x,y;
int *p;
p=&x;
*p=50;
p=&y;
*p=30
}