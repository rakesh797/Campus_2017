#include<stdio.h>
void thinkingmachines(char *);
int main()
{
char a[81];
printf("Enter a string ");
gets(a);
thinkingmachines(a);
printf("[%s]\n",a);
return 0;
}
void thinkingmachines(char *p)
{
char *q=p;
while(*q!='\0')
q++;
q--;
while(q>=p && *q==' ')
q--;
*(q+1)='\0';
q=p;
while(*q==' ') q++;
while(*q!='\0')
{
*p=*q;
p++;
q++;
}
*p='\0';


}