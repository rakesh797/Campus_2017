#include<stdio.h>
int main()
{
int x[5];
int *j=&x;
return 0;
}