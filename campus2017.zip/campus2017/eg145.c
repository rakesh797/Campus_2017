#include<stdio.h>
#include<String.h>
int main()
{ char a[81],b[81];
char *p;
int x;
strcpy(a,"Ujjain");
strcpy(b,"Goa");
printf("%s\n",b);
strcat(a,b);
printf("%s\n",a);
p=strchr(a,'j');
if(p==NULL) {
printf("Not found");
} else {
printf("Found at index %d\n",p-a);
printf("%s\n",p);
}
p=strchr(a,'z');
if(p==NULL) {
printf("Not found\n");
} else {
printf("Found at index %d\n",p-a);
printf("%s\n",p);
}
strcpy(a,"Mumbai");
strcpy(b,"mumbai");
x=strcmp(a,b); // case sensitive comparison
printf("%d\n",x); // 0, greater than 0 or less than 0
x=strcmpi(a,b);
printf("%d\n",x);
printf("%d\n",strlen(a));
p=strdup(a);
printf("%s\n",p);
return 0;
}