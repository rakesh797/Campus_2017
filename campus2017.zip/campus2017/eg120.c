#include<stdio.h>
int main()
{
int x[10];
int lookFor,found,y;
y=0;
while(y<=9)
{
printf("Enter a number");
scanf("%d",&x[y]);
y++;
}
printf("Enter the number to look for ");
scanf("%d",&lookFor);
y=0;
found=0;
while(y<=9)
{
if(x[y]==lookFor)
{
found=1;
break;
}
y++;
}
if(found=0)
{
printf("Not found");
}
else 
{
printf("Found at index %d",y);
}
return 0;
}