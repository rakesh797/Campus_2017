#include<stdio.h>
#include<string.h>
int main()
{
char a[81],b[81];
strcpy(a,"bombay");
strcpy(b,"bombarding");
strrev(a);
printf("%s\n",a);
return 0;
}