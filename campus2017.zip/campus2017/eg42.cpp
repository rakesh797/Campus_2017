#include<stdio.h>
int main()
{
int x,y,z,p;
x=10;
y=10;
z=10;
p=(++x || ++y) && ++z;
printf("%d %d %d\n",x,y,z);
printf("%d\n",p);
return 0;
}