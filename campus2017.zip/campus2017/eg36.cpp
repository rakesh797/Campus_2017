#include<stdio.h>
int main()
{
int x;
x=1;
if(x-- && x--)
{
printf("Great\n");
}
printf("%d\n",x);
return 0;
}