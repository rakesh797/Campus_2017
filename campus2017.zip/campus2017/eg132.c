#include<stdio.h>
int main()
{
int const y=3;
return 0;
}