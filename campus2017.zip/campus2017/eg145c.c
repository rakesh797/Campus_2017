#include<stdio.h>
#include<string.h>
int main()
{
char a[81],b[81];
strcpy(a,"Mumbai");
strcpy(b,"mumbai");
char *p=strdup(b);
printf("%s\n",p);
strlwr(a);
printf("%s\n",a);
strupr(a);
printf("%s\n",a);
strncat(a,b,3);
printf("%s\n",a);
return 0;
}