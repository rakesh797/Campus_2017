#include<stdio.h>
int main()
{
if(1)
{
printf("Hello\n");
}
if(0)
{
printf("God\n");
}
if(2)
{
printf("Great\n");\
}
if(-2)
{
printf("Blue\n");
}
if(-0)
{
printf("God\n");
}

return 0;
}