#include<stdio.h>
int main()
{
int x;
x=10;
printf("%d",x=x+50);

return 0;
}