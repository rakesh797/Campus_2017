#include<stdio.h>
int main()
{
int x[5];
int *p;
p=x;
p=&x[0];
p[0]=60;
printf("%d\n",x[0]);
*(p+4)=100;
printf("%d\n",x[4]);
*(x+2)=200;
return 0;
}