#include<stdio.h>
void show();
void main()
{
show();
}
void show()
{
printf("I'm the greatest");
}