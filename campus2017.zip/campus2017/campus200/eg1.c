#include<stdio.h>
int i=10;
int main()
{
int a[2][2][2]={{10,2,3,4},{5,6,7,8}};
int *p,*q;
p=&a[2][2][2];
printf("%d\n",*p);
*q=***a;
printf("%d\n",*q);
return 0;
}