#include<stdio.h>
int main()
{
int i=400,j=300;
printf("%d..%d");
}