#include<stdio.h>
int main()
{
printf("%x",-1<<4);
return 0;
}