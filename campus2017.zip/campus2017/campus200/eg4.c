#include<stdio.h>
int main()
{
int c=- -2;
printf("c=%d",c);
return 0;
}