#include<stdio.h>
int main()
{
printf("\nab");
printf("\bsi");
printf("\rha");
return 0;
}