#include<stdio.h>
int main()
{
int i=10;
i=!i;
printf("i=%d",i);
return 0;
}