#include<stdio.h>
int main()
{
int p;
p=10-20*3/3/10+1;
printf("%d\n",p);
return 0;
}