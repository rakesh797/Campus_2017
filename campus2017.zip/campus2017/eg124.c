#include<stdio.h>
int main()
{
int x[10],y,lookFor,count,z,found,e;
y=0;
while(y<=9)
{
printf("Enter a number ");
scanf("%d",&x[y]);
y++;
}
z=0;
while(z<=9)
{
lookFor=x[z];
found=0;
e=0;
while(e<=z-1)
{
if(lookFor=x[e])
{
found=1;
break;
}
e++;
}
if(found==0)
{
count=1;
y=z+1;
while(y<=9)
{
if(lookFor==x[y])
{
count++;
}
y++;
}
if(count==1)
{
printf("%d occurs 1 time\n",lookFor);
}else
{
printf("%d occurs %d times\n",lookFor,count);
}
}
z++;
}
return 0;
}