#include<stdio.h>
#include<alloc.h>
static int p; //will get default value -> 0 storage ->data segment
int j;
extern int r; // memory won't be allocated for r
void lmn();
int main()
{
register int m; //will get space in CPU memory
lmn();
return 0;
}
void lmn()
{
int *g; // stack=remainingmemory
static int x; // will get default value-> 0 -> data segment
int y; //stack -remaining memory
auto int z;
printf("%d\n",p);
printf("%d\n",x);
g=(int *)malloc(2); //allocation in heap (remaining /data segment)
g=(int *)calloc(10,2); //allocation in heap (remaining /data segment)
}