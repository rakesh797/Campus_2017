#include<malloc.h>
#include<string.h>
#include<stdio.h>
#include<stdarg.h>
char * sam(char *string,...)
{
va_list valist;
int bufferSize=50;
char *arr=(char *)malloc(sizeof(char)*bufferSize);
char c,d;
char number[21];
int numberLength;
int i,ai;
va_start(valist,string);
i=0;
ai=0;
while(string[i]!='\0')
{ 
if(string[i]!='%')
{
arr[ai]=string[i];
ai++;
if(ai==bufferSize-1 && string[i+1]!='\0')
{
bufferSize+=50;
arr=(char *)realloc(arr,bufferSize);
} 
i++;
continue;
} 
if(string[i]=='%' && string[i+1]!='\0')
{ 
if(string[i+1]=='d')
{ 
itoa(va_arg(valist,int),number,10);
numberLength=strlen(number);
if(ai+numberLength>bufferSize-1)
{
bufferSize=bufferSize+50;
arr=(char *)realloc(arr,bufferSize);
}
strcpy(arr+ai,number);
ai+=numberLength;
i++;
} else if(string[i+1]=='c')
{
} else if(string[i+1]=='s')
{
} else if(string[i+1]=='u')
{
}
else
{ 
arr[ai]=string[i];
ai++;
if(ai==bufferSize-1 && string[i+1]!='\0')
{
bufferSize+=50;
arr=(char *)realloc(arr,bufferSize);
}
}
} 
i++;
}
va_end(valist);
arr[ai]='\0';
return arr;
} int main()
{ char a[301];
char *p=sam("God %d is %d %rABgreat",10,20234);
strcpy(a,p);
printf("%s",a);
free(p);
return 0;
}