#include<stdio.h>
int main()
{
int x;
x=64&32;
printf("%d",x);
return 0;
}