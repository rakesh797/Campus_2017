#include<stdio.h>
int main()
{
int x[5];
int *p;
int **j;
p=x;
j=&x;
return 0;
}
