#include<stdio.h>
#define pr printf
int main()
{
pr("ujjain is a cool city");
printf("God is great");
return 0;
}