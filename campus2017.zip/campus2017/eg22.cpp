#include<stdio.h>
int main()
{
int x;
x=printf("%d %d %d",10,20,30);
printf("\n%d\n",x);
x=printf("%d%d%d",10,20,30);
printf("\n%d",x);
return 0;
}