#include<stdio.h>
int main()
{
int m[3][6];
printf("%d\n",sizeof(m));
printf("%u\n",m);
printf("%u\n",m[0]);
printf("%u\n",&m[0]);
printf("%u\n",m+1);
printf("%u\n",m[1]);
printf("%u\n",&m[1]);
printf("%u\n",m+2);
printf("%u\n",m[2]);
printf("%u\n",&m[2]);
return 0;
}