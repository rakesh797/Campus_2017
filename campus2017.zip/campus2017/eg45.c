#include<stdio.h>
#include<string.h>
int main()
{
char a[81],b[81];
char *p;
int x;
strcpy(a,"Ujjain");
strcpy(b,"Goa");
printf("%s\n",b);
strcat(a,b);
printf("%s\n",a);
p=strchr(a,'j');
if(p==NULL)
{
printf("Not found");
}else
{
printf("Found at index %d\n",p-a);
printf("%s\n",p);
}
p=strchr(a,'z');
if(p==NULL)
{
printf("Not found\n");
}else
{
printf("Found at index %d\n",p-a);
printf("%s\n",p);
}
return 0;
}