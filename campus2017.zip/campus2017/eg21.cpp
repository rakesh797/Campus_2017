#include<stdio.h>
int main()
{
int x,y,z;
x=10;
y=20;
z=30;
printf("%d %d %d",printf("%d",x),printf("%d",y),printf("%d",z));
return 0;
}