#include<stdio.h>
int main()
{
char m;
m='A';
if((m>=48 && m<=57)?1:0){
printf("%c is a digit\n",m);
}else
{
printf("%c is not a digit\n",m);
}
}