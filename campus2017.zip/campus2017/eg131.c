#include<stdio.h>
int main()
{
int x,y;
const int *p=&x;
p=&y;
*p=60;
return 0;
}