#include<stdio.h>
void thinkingMachines(char *);
int main()
{
char a[81];
printf("Enter a string");
gets(a);
thinkingMachines(a);
printf("[%s]\n",a);
return 0;
}
void thinkingMachines(char *p)
{
char *q=p;
while(*q==' ') q++;
while(*q!='\0')
{
*p=*q;
p++;
q++;
}
*p='\0';
}