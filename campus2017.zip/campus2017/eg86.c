#include<stdio.h>
int main()
{
int x,y,count;
printf("Enter a number");
scanf("%d",&x);
count=0;
for(y=x;y;y=y>>1) if(y & 1) count++;
printf("%d\n",count);
return 0;
}