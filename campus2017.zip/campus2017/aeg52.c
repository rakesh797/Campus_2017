#include<stdio.h>
int main()
{
int x;
x=2147483649;
printf("%d",x);
return 0;
}