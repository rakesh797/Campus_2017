#include<stdio.h>
int main()
{
char x;
x=256;
printf("%d",x);
return 0;
}