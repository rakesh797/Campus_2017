#include"anil.h"
extern int x;
int main()
{
x=10;
cool();
return 0;
}

//gcc -static eg118.c -l libanil -L . -o eg118.exe