#include<stdio.h>
struct abc
{
int x,y;
char g,t;
};
int main()
{
struct abc m[5];
printf("Size of m is %d\n",sizeof(m));
printf("Size of m[0] is %d\n",sizeof(m[0]));
printf("Address retrieved through &m is %u\n",&m);
printf("Address retrieved through m is %u\n",m);
printf("Address retrieved through &m[0] is %u",m);
printf("---------------\n");
printf("m+1 gives %u\n",m+1);
printf("&m[0]+1 gives %u\n",&m[0]+1);
printf("&m[1] gives %u\n",&m[1]);
printf("&m+1 gives %u\n",&m+1);
printf("-------------------\n");
printf("m+2 gives %u\n",m+2);
printf("&m[0]+2 gives %u\n",&m[0]+2);
printf("&m[2] gives %u\n",&m[2]);
printf("&m+2 gives %u\n",&m+2);
printf("----------------\n");
printf("m+3 gives %u\n",m+3);
printf("&m[0]+3 gives %u\n",&m[0]+3);
printf("&m[3] gives %u\n",&m[3]);
printf("&m+3 gives %u\n",&m+3);
printf("----------------\n");
printf("m+4 gives %u\n",m+4);
printf("&m[0]+4 gives %u\n",&m[0]+4);
printf("&m[4] gives %u\n",&m[4]);
printf("&m+4 gives %u\n",&m+4);
printf("----------------\n");
printf("m+5 gives %u\n",m+5);
printf("&m[0]+5 gives %u\n",&m[0]+5);
printf("&m[5] gives %u\n",&m[5]);
printf("&m+5 gives %u\n",&m+5);
printf("----------------\n");

}