#include<STDIO.h>
#define uj printf
int main()
{
uj("hello");
return 0;
}