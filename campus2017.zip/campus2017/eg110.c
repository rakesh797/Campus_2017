#include<stdio.h>
void thinkingmachines(char *);
int main()
{
char a[80];
printf("Enter a number ");
gets(a);
thinkingmachines(a);
printf("%s",a);
return 0;
}
void thinkingmachines(char *p)
{
char *q;
while(*p!='\0') p++;
q=p;
while(p<q)
{
*p=*p+*q;
*q=*p-*q;
*p=*p-*q;
p++;
q--;
}
}