#include<stdio.h>
int lmn()
{
printf("left\n");
return 1;
}
int pqr()
{
printf("middle\n");
return 0;
}
int rst()
{
printf("right\n");
return 0;
}
int main()
{
int x;
x=(lmn() || pqr()) && rst();
printf("%d",x);
return 0;
}