#include<stdio.h>
#include<String.h>
int main()
{
char a[21];
printf("Enter a string :");
gets(a);
if(strcmp(strrev(strdup(a)),a))
{
printf("Pallindrom");
}else
{
printf("not a pallindrom");
}
return 0;
}