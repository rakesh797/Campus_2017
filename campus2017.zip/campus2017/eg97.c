#include<stdio.h>
int main()
{
int x[5];
int (*j)[5]; //type of j is int[5]*
j=&x;
printf("%u\n",&x);
printf("%u\n",j);
printf("%u\n",&x+1);
printf("%u\n",j+1);
return 0;
}